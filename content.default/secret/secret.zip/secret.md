# Secret Archive Content

You downloaded `secret.zip`! This file was protected by the folder password: `secret`.

This demonstrates that binary/archive assets can be gated behind the same password
rules as markdown pages. The `/gate/` route handles the download prompt.
