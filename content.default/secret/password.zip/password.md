# Password Archive Content

You downloaded `password.zip`! This file was protected by its own rule with password: `password`.

Even though it lives inside `/secret`, it has a per-file rule that overrides the folder password.
